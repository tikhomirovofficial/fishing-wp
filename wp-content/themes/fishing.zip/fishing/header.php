<?php
/**
 * Header file for the Twenty Twenty WordPress default theme.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

?><!DOCTYPE html>

<html class="no-js" <?php language_attributes(); ?>>

	<head>

		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" >

		<link rel="profile" href="https://gmpg.org/xfn/11">

		<?php wp_head(); ?>

	</head>

	<body <?php body_class(); ?>>

		<?php
		wp_body_open();
		?>

        <header>
            <div class="wrapper">
                <div class="header__block flex-row-betw al-center">
                    <div class="header__present d-f al-center">
                        <img class="header__logo" src="assets/img/logo.png" alt="">
                        <p>Платная рыбалка в Подмосковье</p>
                    </div>
                    <nav>
                        <ul class="header__nav d-f">
                            <li><a class="fade-scroll header__link" href="#prices">Цены</a></li>
                            <li><a class="fade-scroll header__link" href="#hotel">Гостиницы</a></li>
                            <li><a class="header__link" href="gallery.html">Галерея</a></li>
                            <li><a class="fade-scroll header__link" href="#contacts">Контакты</a></li>
                        </ul>
                    </nav>
                    <div class="header__callback">
                        <a class="header__phone" href="tel:79269119407">+7 (926) 911-94-07</a>
                        <p>ежедневно с 7:00 до 20:00</p>

                    </div>
                </div>
            </div>
        </header>

		<?php
		// Output the menu modal.
		get_template_part( 'template-parts/modal-menu' );
